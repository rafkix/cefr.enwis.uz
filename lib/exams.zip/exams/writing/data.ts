import { WritingTest } from "./types"

export const writingTests: WritingTest[] = [
  {
    id: "writing-test-fitness-1",
    title: "Writing Test – Fitness Club",
    isDemo: false,
    isFree: true,
    cefrLevel: "C1",
    durationMinutes: 60,

    tasks: [
      {
        id: "1.1",
        type: "informal-letter",
        instruction: "Write a short informal letter.",
        prompt: `You are a member of a fitness club. You received the following email from the manager:

"Dear member,

I am sorry to inform you that the fitness center will be closed for one month starting next Monday. The building needs some repairs, and we also plan to install new equipment.

What else do you think should be changed? As the center will not be operating for a month, what kind of alternative activities should we organize in the meantime?

We appreciate your opinion very much.
The Manager."

Write a letter to a friend who is also a member of the club:
- explain how you feel about the situation
- say what you think the club management should do

Write about 50 words.`,
        minWords: 40,
        maxWords: 60,
        targetLevel: "A2-B1",
      },

      {
        id: "1.2",
        type: "formal-letter",
        instruction: "Write a formal letter.",
        prompt: `You are a member of a fitness club. You received the following email from the manager:

"Dear member,

I am sorry to inform you that the fitness center will be closed for one month starting next Monday. The building needs some repairs, and we also plan to install new equipment.

What else do you think should be changed? As the center will not be operating for a month, what kind of alternative activities should we organize in the meantime?

We appreciate your opinion very much.
The Manager."

Write a letter to the manager:
- explain how you feel about the closure
- suggest what improvements should be made
- recommend alternative activities during the closure

Write 120–150 words.`,
        minWords: 120,
        maxWords: 150,
        targetLevel: "B1-B2",
      },

      {
        id: "2",
        type: "opinion-essay",
        instruction: "Write an opinion essay.",
        prompt: `You are participating in an online discussion for language learners.

The question is:

"Is it better to live in a big city or a small town?"

Give your opinion and support it with reasons and examples. You may discuss both sides of the issue.

Write 180–200 words.`,
        minWords: 180,
        maxWords: 200,
        targetLevel: "B2-C1",
      },
    ],
  },
]
