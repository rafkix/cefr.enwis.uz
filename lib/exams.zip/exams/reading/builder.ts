// lib/exams/reading/builder.ts
import { ExamSet, ReadingPart, Question } from "./types";
import { readingExamRaw } from "./data";

export function buildReadingExam() {
  const raw = readingExamRaw;

  return {
    meta: {
      id: raw.id,
      title: raw.title,
      level: raw.cefr_level,
      duration: raw.duration_minutes,
    },
    parts: raw.parts.map(part => ({
      ...part,
      questions: part.questions.map(q => ({
        ...q,
        // UI uchun qo'shimcha formatlash kerak bo'lsa shu yerda qilinadi
        displayId: `Q-${q.id}`
      }))
    }))
  };
}